# Aditya Balwani
# SBUID: 109353920

class SyntaxError(Exception):
    """
    This is the class of the exception that is raised when a semantic error
    occurs.
    """
