# Aditya Balwani
# SBUID: 109353920

global variables
variables = []
