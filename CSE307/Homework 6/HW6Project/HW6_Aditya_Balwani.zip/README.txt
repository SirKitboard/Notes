CSE 307 Homework 6

Made by Aditya Balwani
SBU ID 109353920

Use hw6.py to test code with python style indented blocks

Use hw6cstyle.py to test code with C-style blocks
