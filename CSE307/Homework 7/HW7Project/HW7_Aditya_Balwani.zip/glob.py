global variables
variables = []
global functions
functions = []
