CSE 307 Homework 6

Made by Aditya Balwani
SBU ID 109353920

Please remove semicolons from all assignment and return statements before testing
