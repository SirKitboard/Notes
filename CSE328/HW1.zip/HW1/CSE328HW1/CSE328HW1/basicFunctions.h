#pragma once

float min(float a, float b);
float max(float a, float b);