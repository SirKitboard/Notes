#!/usr/bin/env perl

use strict;
use warnings;
print "hello "x5 . "\n";
